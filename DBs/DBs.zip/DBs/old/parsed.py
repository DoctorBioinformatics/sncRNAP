import os
from Bio import SeqIO

# Define the directory containing the files
directory = "/Users/hgibriel/Dropbox/sncRNAP/DBs/"

# Iterate over the files in the directory
for filename in os.listdir(directory):
    if filename.endswith("mirdeep.fa"):
        # Define the input and output filenames
        input_filename = os.path.join(directory, filename)
        output_filename = os.path.join(directory, input_filename+".finalized.fa")

        # Open the input and output files
        with open(output_filename, "w") as f_out:
            # Iterate over the sequences in the input file
            for record in SeqIO.parse(input_filename, "fasta"):
                # Get the header and extract the gene biotype if present
                header = record.description
                if header.startswith(">"):
                    header = header[1:]
                gene_biotype = None
                if "gene_biotype" in header and 'transcript_biotype' not in header:
                    gene_biotype = header.split("gene_biotype ")[1].split(";")[0].replace('"', '')

                    # Extract the gene ID and modify the header
                    gene_id = header.split("gene_id ")[1].split(";")[0].replace('"', '')
                    if gene_biotype is not None:
                        new_header = ">{}_{}\n".format(gene_id, gene_biotype)
                    else:
                        new_header = ">{}\n".format(gene_id)
                elif "trna" in header:
                    new_header = ">{}\n".format(header.split()[0])
                elif "MIMAT" in header:
                    new_header = ">{}_{}\n".format(header.split()[0], header.split()[1])
                elif "lookalike" in header:
                    # Skip sequences with unwanted headers
                    continue
                # elif "Mt" in header:
                #     # Skip sequences with unwanted headers
                #     continue                
                else:
                    new_header = ">" + header + "\n"
                # Write the new header and sequence to the output file
                f_out.write(new_header)
                f_out.write(str(record.seq) + "\n")
